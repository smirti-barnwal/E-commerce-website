//1. Ways to print in js
console.log("Hello World");
// alert("me");
document.write("This is  document write");
// this helps to print message in inspect as well as browser


//2. Javascript console API 
console.log("Hello World",4 + 6, "Another log");
console.warn("This is warning");
// print  warning in console
console.error("this is an error");
// print error in console
// console.clear()  console.assert()---pass when statement inside is right


//3. Variables in JS
// variables are ---- containers to store data values
var number1 = 92;
var number2 = 98;
console.log(number1 + number2);
/*
multi 
line
comment
*/

 //4. Data Types in Javascript
 //Numbers
 var num1 = 900;
 var num2 = 1000;

 //String
 var str1 = "This is a string";
 var str2 = 'This is also a string';

 //Objects -- key value pairs
 var marks = {
 	ravi: 65,
 	shubham: 78,
 	smirti: 99
 };
console.log(marks);

// Booleans
var t = true;
var f = false;
console.log(t,f);

var und = undefined;
var un;//bydefault variable ki value undefined hoti h
console.log(undefined);
console.log(und);
console.log(un);

var n = null;
console.log(n);

Symbol('HEllo');//aandar ek string leta h symbol

/*Two types of data types:
1.Primitive - undefined,null,number,string,boolean, symbol
2. Reference - Arrays and Objects
*/

// Array
var arr = [1,2,3,4,5,"strings"];
console.log(arr);
console.log(arr[0]);


// 5. Operators in Javascript
// Arithmetic Operators 
var a = 98;
var b = 94;
console.log("The value of a + b is ", a + b);
console.log("The value of a - b is ", a - b);
console.log("The value of a * b is ", a * b);
console.log("The value of a / b is ", a / b);

// Assignment Operators-----v
var c= b;
c += 2;
// c *= 2;
console.log(c);

// Comparison Operators
var x = 95;
var y = 98;
// console.log(x == y);
// console.log(x <= y);
// console.log(x >= y);
// console.log(x > y);
//console.log(x < y);

// Logical Operator -- boolean 
// console.log(true && true);
// console.log(true && false);
// console.log(false && true);
// console.log(false && false);

// console.log(true || true);
// console.log(true || false);
// console.log(false || true);
// console.log(false || false);
console.log(!false);//logical not
console.log(!true);


// Function in Javascript
function avg(a,b){
    return (a + b)/2;
}
// DRY - do not repeat yourself
c1 = avg(4,6);
c2 = avg(10,30);
console.log(c1,c2);

// Conditions in JS
var age = 34;
if(age > 18)
    console.log('You can drink');
else
    console.log('You can not drink');

if(age > 20 && age < 25)
    console.log("Not a kid");
else if(age >25 && age < 60)
    console.log("Earning is important");
else
    console.log("take some rest");

//LOOPs in JS

var arr = [1,2,3,4,5,6,7,8,9,10];
console.log(arr);
// for(var i=0; i< arr.length; i++){
    // if(j == 2)
    //     continue;
//     console.log(arr[i]);
// }


// arr.forEach(function(element){
//     console.log(element);
// })

let j=0;
// const j=0;
// while(j < arr.length){
//     console.log(arr[j]);
//     j++;
// }

do{
    console.log(arr[j]);
    j++;
    // if(j == 2)
    //     break;
}while(j < arr.length);

// Array method 
let myArr = ["Fan", "Camera", 48, null, true];

console.log(myArr.length);
myArr.pop();
myArr.push("Smirti");
myArr.shift();//first element remove ho jata h
myArr.unshift("barnwal");//add element in first position
console.log(myArr.unshift("barnwal"));//prints length of new array formed
console.log(myArr);
console.log(myArr.toString());
// myArr.toString(); myArr.sort();write in console converts to string and sort respectively
// sort m first numbers string m  convert hota h or phir alphatically arrange krta 


// String Method
let mystr = "Smirti will get high paid intern paid";
console.log(mystr);
console.log(mystr.length);
console.log(mystr.indexOf("paid"));//first word k hi index print krta h
console.log(mystr.lastIndexOf("paid"));
console.log(mystr.slice(0,4));
console.log(mystr.slice(2,10));

d = mystr.replace("high", "very-high");
d = d.replace("will","definetly will")
console.log(d);
console.log(mystr);


// Dates in JS
let mydate = new Date();
console.log(mydate);
console.log(mydate.getTime());//give time in seconds
console.log(mydate.getFullYear());//print year
console.log(mydate.getDay());//s m t w th f s print num
console.log(mydate.getMinutes());
console.log(mydate.getHours());


//DOM manipulation -(Document Object Model)
// DOM is basically document jo hume pg m dikhta h (html hi dom h woh console se manipulate ho skta h)
let elm = document.getElementById ('click');
console.log(elm);

let elmclass = document.getElementsByClassName ("container");
console.log(elmclass);
// elmclass[0].style.background = "yellow";
elmclass[0].classList.add("bg-primary");
elmclass[0].classList.add("text-sucess");
// elmclass[0].classList.remove("text-sucess");

console.log(elmclass[0].innerHTML);
console.log(elmclass[0].innerText);
console.log(elm.innerHTML);
console.log(elm.innerText);

tn = document.getElementsByTagName('div');
console.log(tn);
createdElement = document.createElement('p');
createdElement.innerText = "This is created para";
tn[0].appendChild(createdElement);//1st div m add kr diya new created element

createdElement2 = document.createElement('b');
createdElement2.innerText = "This is created bold";
tn[0].replaceChild(createdElement2,createdElement);//1st div m replace kr diya new created element ko

// removeChild(element); ----> removes an element

/*
document.URL
document.links
document.scripts
document.title
document.images
document.domain
*/
// selecting using query

sel = document.querySelector('.container');
console.log(sel);//first container is printed

sel2 = document.querySelectorAll('.container');
console.log(sel2);//ALL container is printed


 function clicked(){
    console.log('The button is clicked');
 } 

window.onload = function(){
    console.log('The document was loaded');
 }  


// Events in JavaScript
//events jo ho rha h 

// firstcontainer.addEventListener('click',function(){
//     //agr koi click krega toh yeh bata dega yeh event hua console m below message print krega
//     document.querySelectorAll('.container')[1].innerHTML = "<b> We have clicked container</b>"
//     console.log('clicked on container');
// })

// firstcontainer.addEventListener('mouseover',function(){
//     //agr mouse button m jayga toh yeh bata dega yeh event hua console m below message print krega
//     console.log('mouse on container');
// })

// firstcontainer.addEventListener('mouseout',function(){
//     console.log('mouse out of container');
// })

let prevhtml = document.querySelectorAll('.container')[1].innerHTML;

firstcontainer.addEventListener('mouseup',function(){
    //mouse button k h
    document.querySelectorAll('.container')[1].innerHTML = prevhtml;
    console.log('mouse up when clicked on container');
})

firstcontainer.addEventListener('mousedown',function(){
    document.querySelectorAll('.container')[1].innerHTML = "<b> We have clicked container</b>";
    console.log('mouse down when clicked on container');
})

//Arrow Functions
// function sum(a,b){
//     return (a+b);
// }
sum = (a,b)=>{
    return a+b;
}//bich m function add/fit krne k liye use hota h


// SetTimeout and setInterval-->schedule things 
logkro = ()=>{
    document.querySelectorAll('.container')[1].innerHTML = "<b> Set timeout fired</b>"
    console.log("I'm ur log");
}
setTimeout(logkro,2000);//ek br func call hoga
//first argument-> function 2nd arg-> kitne ms k baad run krna chahte h
//use clearTimeout()/clearInterval() to cancel setTimeout/setInterval

//setinterval when kisi chij ko repeatedly krwani h
// clr = setInterval(logkro,2000);//hr 2sec m fun call hoga
//clr will be an id-> console-> use clearInterval(clr) m krengen toh yeh repeated call of func band ho jayga


//Local Storage in JavaScript
//console--> localStorage.setItem('name', 'smirti')---->localStorage->print ls 
//localStorage.getItem('name')-->o/p-->smirti
// localStorage.removeItem(name);
// localStorage.clear()

//JSON --> JavaScript object Notation  is a lightweight data-interchange format. It is easy for humans to read and write. It is easy for machines to parse and generate.
obj = {name: "harry", length: 1, a: {this: "that"}}
jso = JSON.stringify(obj);//convert object to string
console.log(typeof(jso));
console.log(jso);
//json only supports double quotes but object in js accept ''

parsed = JSON.parse('{"name":"harry","length":1,"a":{"this":"that"}}')//convert string to object
console.log(typeof(parsed));
console.log(parsed);


//JavaScript Versions-->ECMAScript-- JS is standard
//JS k updates ECMA m push hoti h or iss tarah se ek standard maintain hota h

//template literals - Backticks
a = 34;
console.log(`this is my ${a}`);
//Template literals are string literals allowing embedded expressions. You can use multi-line strings and string interpolation features with them.
a = 5;
b = 10;
console.log(`Fifteen is ${a + b} and not ${2 * a + b}.`);